//: Playground - noun: a place where people can play

import UIKit


var serie = 0...100

for valor in serie{
    if (valor % 5 == 0){
        print("# \(valor) BINGO")
    }else if(valor % 2 == 0){
        print("# \(valor) PAR")
    }else if(valor >= 30 && valor <= 40){
        print("# \(valor) VIVA SWIFT")
    }
}

